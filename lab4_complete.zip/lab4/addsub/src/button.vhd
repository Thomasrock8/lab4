-------------------------------------------------------------------------------
-- Dr. Kaputa
-- seven_seg demo
-------------------------------------------------------------------------------
library ieee;
use ieee.std_logic_1164.all;      

entity button is
  port (
    clk             : in std_logic; 
    reset           : in std_logic;
    add_s           : in std_logic;
	sub_s           : in std_logic;
    flag            : out std_logic
  );  
end button;  

architecture beh of button is
begin
process(clk,reset)
  begin
    if (reset = '1') then 
	flag <= '0';
    elsif (clk'event and clk = '1') then
		if(add_s = '1') then
		  flag <= '0';
		elsif (sub_s = '1') then
		  flag <= '1';
     end if;
	end if;
  end process;
end beh;