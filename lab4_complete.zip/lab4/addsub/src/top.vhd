-------------------------------------------------------------------------------
-- Dr. Kaputa
-- blink top
-------------------------------------------------------------------------------
library ieee;
use ieee.std_logic_1164.all;

entity top is
  port (
    clk             : in  std_logic; 
    reset           : in  std_logic;
	a               : in  std_logic_vector(2 downto 0);
    b               : in  std_logic_vector(2 downto 0);
	add             : in  std_logic;
	sub             : in  std_logic; 
    seven_seg1      : out std_logic_vector(6 downto 0);
	seven_seg2      : out std_logic_vector(6 downto 0);
	seven_seg3      : out std_logic_vector(6 downto 0)
  );
end top;

architecture beh of top is

signal flag     :std_logic;
signal add_s    :std_logic;
signal sub_s    :std_logic;
signal a_s      :std_logic_vector(2 downto 0);
signal b_s      :std_logic_vector(2 downto 0);
signal a_pad    :std_logic_vector(3 downto 0);
signal b_pad    :std_logic_vector(3 downto 0);
signal result   :std_logic_vector(3 downto 0);

component seven_seg is
  port (
    clk             : in std_logic; 
    reset           : in std_logic;
    bcd             : in std_logic_vector(3 downto 0);
    seven_seg_out   : out std_logic_vector(6 downto 0)
  );  
end component; 

component synchronizer_3bit is
  port (
    clk             : in std_logic; 
    reset           : in std_logic;
    async_in        : in std_logic_vector(2 downto 0);
    sync_out        : out std_logic_vector(2 downto 0)
  );  
end component; 

component rising_edge_synchronizer is
  port (
    clk               : in std_logic;
    reset             : in std_logic;
    input             : in std_logic;
    edge              : out std_logic
  );  
end component; 

component button is
  port (
    clk             : in std_logic; 
    reset           : in std_logic;
    add_s           : in std_logic;
	sub_s           : in std_logic;
    flag            : out std_logic
  );  
end component; 

component add_sub is
  port (
    clk             : in std_logic; 
    reset           : in std_logic;
	flag            : in std_logic;
    a               : in std_logic_vector(3 downto 0);
	b               : in std_logic_vector(3 downto 0);
    result          : out std_logic_vector(3 downto 0)
  );  
end component; 

begin
process(clk,reset)
begin
a_pad <= '0' & a_s;
b_pad <= '0' & b_s;
end process;

uutas: add_sub
  port map(        
    clk            => clk,
    reset          => reset,
	flag           => flag,
    a              => a_pad,
	b              => b_pad,
    result         => result
  );

uutf: button
  port map(        
    clk            => clk,
    reset          => reset,
    add_s          => add_s,
	sub_s          => sub_s,
    flag           => flag
  );

uutr1: synchronizer_3bit
  port map(        
    clk            => clk,
    reset          => reset,
    async_in       => a,
    sync_out       => a_s
  );
  
  uutr2: synchronizer_3bit
  port map(        
    clk            => clk,
    reset          => reset,
    async_in       => b,
    sync_out       => b_s
  );
  
  uutr3: rising_edge_synchronizer
  port map(        
    clk            => clk,
    reset          => reset,
    input          => add,
    edge           => add_s
  );

  uutr4: rising_edge_synchronizer
  port map(        
    clk            => clk,
    reset          => reset,
    input          => sub,
    edge           => sub_s
  );

uuts1: seven_seg
  port map(        
    clk            => clk,
    reset          => reset,
    bcd            => a_pad,
    seven_seg_out  => seven_seg1
  );
  
  uuts2: seven_seg
  port map(        
    clk            => clk,
    reset          => reset,
    bcd            => b_pad,
    seven_seg_out  => seven_seg2
  );
  
  uuts3: seven_seg
  port map(        
    clk            => clk,
    reset          => reset,
    bcd            => result,
    seven_seg_out  => seven_seg3
  );
  
 
  end beh;