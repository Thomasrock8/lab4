-------------------------------------------------------------------------------
-- Dr. Kaputa
-- seven_seg demo
-------------------------------------------------------------------------------
library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;      

entity add_sub is
  port (
    clk             : in std_logic; 
    reset           : in std_logic;
	flag            : in std_logic;
    a               : in std_logic_vector(3 downto 0);
	b               : in std_logic_vector(3 downto 0);
    result          : out std_logic_vector(3 downto 0)
  );  
end add_sub;  

architecture beh of add_sub  is
begin
process(clk,reset)
  begin
    if (reset = '1') then 
	result <= "0000";
    elsif (clk'event and clk = '1') then
		if(flag = '0') then
		result <= std_logic_vector(unsigned(a) + unsigned(b));
		elsif(flag = '1') then
		result <= std_logic_vector(unsigned(a) - unsigned(b));
		end if;
    end if;
  end process;
end beh;